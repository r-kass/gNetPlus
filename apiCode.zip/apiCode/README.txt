Download wamp64.

In C:\wamp64\www\ directory add the rest of the files.

Take the Php.ini file into C:\wamp64\bin\apache\apache2.4.23\bin


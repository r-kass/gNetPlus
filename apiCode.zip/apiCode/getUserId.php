<?php
// Code adapted from Youtube User: simply teaching
//https://www.youtube.com/watch?v=C9ckXWHnu5g 
/*
 * Sample application for Google+ client to server authentication.
 * Remember to fill in the OAuth 2.0 client id and client secret,
 * which can be obtained from the Google Developer Console at
 * https://code.google.com/apis/console
 *
 * Copyright 2013 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * Note (Gerwin Sturm):
 * Include path is still necessary despite autoloading because of the require_once in the libary
 * Client library should be fixed to have correct relative paths
 * e.g. require_once '../Google/Model.php'; instead of require_once 'Google/Model.php';
 */
set_include_path(get_include_path() . PATH_SEPARATOR . __DIR__ .'/vendor/google/apiclient/src');

//require_once 'src/Google/autoload.php';
require_once __DIR__.'/vendor/autoload.php';

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Simple server to demonstrate how to use Google+ Sign-In and make a request
 * via your own server.
 *
 * @author silvano@google.com (Silvano Luciani)
 */

/**
 * Replace this with the client ID you got from the Google APIs console.
 */
//const CLIENT_ID = '1024902016293-i54fnl62a4gn58e3kaslc950na4gtv4g.apps.googleusercontent.com';
const CLIENT_ID = '1024902016293-5ivc7hh43jofr6c8k068ibv82f084cjh.apps.googleusercontent.com';
/**
 * Replace this with the client secret you got from the Google APIs console.
 */
//const CLIENT_SECRET = '1024902016293';
const CLIENT_SECRET = '-A9k4lOxBO2QwHEw_0aCQ805';
/**
 * Optionally replace this with your application's name.
 */
const APPLICATION_NAME = "gNET";

$userDataFile = fopen("userDataFile.txt", "w");

$client = new Google_Client();
$client->setApplicationName(APPLICATION_NAME);
$client->setClientId(CLIENT_ID);
$client->setClientSecret(CLIENT_SECRET);
$client->setRedirectUri('http://localhost/getUserId.php');
$client->setScopes('email');

$plus = new Google_Service_Plus($client);

if(isset($_REQUEST['logout'])){
	session_unset();
}

if(isset($_GET['code'])){
	$client->authenticate($_GET['code']);
	$_SESSION['access_token'] = $client->getAccessToken();
	
	
}


if(isset($_SESSION['access_token'])){
	$client->setAccessToken($_SESSION['access_token']);
	$me = $plus->people->get('me');
	$displayName = $me['displayName'];
	$displayName = $displayName . '%';
	$emails = $me['emails'];
	$firstEmail = $emails[0];
	$email = $firstEmail['value'] . '%';
	print($displayName);
	print($email);
	fwrite($userDataFile, $displayName );
	fwrite($userDataFile, $email);
	fclose($userDataFile);
}
else{
	$authUrl = $client->createAuthUrl();
	echo '<a href = "'.$authUrl.'">login to google </a>';

}


?>
